﻿<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php

header("Content-Type:text/html; charset=utf-8");

$host='127.0.0.1';
$username='root';
$pwd='';
$db="taesuplace";
$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');
mysql_query("set names utf8");

mysql_query("set session character_set_connection=utf8;");

mysql_query("set session character_set_results=utf8;");

mysql_query("set session character_set_client=utf8;");

if(mysqli_connect_error($con))
{
	echo "Failed to Connect to Database ".mysqli_connect_error();
}
$title=$_POST['title'];
$nic=$_POST['nic'];
// $date=$_POST['desiredCareSex'];
$patientGender=$_POST['patientgender'];
$age=$_POST['age'];
$patientsSymptoms=$_POST['sympton'];
$address=$_POST['address'];
$contactNumber=$_POST['phone'];
$cost=$_POST['cost'];
$termstart=$_POST['term'];
$desiredCareSex=$_POST['hopegender'];
$requirementsWord=$_POST['contect'];

// echo $patientGender;
// echo $ages;
// echo $desiredCareSex;
// echo $patientsSymptoms;
// echo $address;
// echo $contactNumber;
// echo $requirementsWord;

// $patientGender=urlencode('한글');
// $ages=urlencode('한글');
// $desiredCareSex=urlencode('한글');
// $patientsSymptoms=urlencode('한글');
// $address=urlencode('한글');
// $contactNumber=urlencode('한글');
// $requirementsWord=urlencode('한글');

// $patientGender=urldecode('한글');
// $ages=urldecode('한글');
// $desiredCareSex=urldecode('한글');
// $patientsSymptoms=urldecode('한글');
// $address=urldecode('한글');
// $contactNumber=urldecode('한글');
// $requirementsWord=urldecode('한글');

// $patientGender=iconv('euc-kr', 'utf-8', $patientGender);
// $ages=iconv('euc-kr', 'utf-8', $ages);
// $desiredCareSex=iconv('euc-kr', 'utf-8', $desiredCareSex);
// $patientsSymptoms=iconv('euc-kr', 'utf-8', $patientsSymptoms);
// $address=iconv('euc-kr', 'utf-8', $address);
// $contactNumber=iconv('euc-kr', 'utf-8', $contactNumber);
// $requirementsWord=iconv('euc-kr', 'utf-8', $requirementsWord);



$sql="INSERT INTO find_caregiver
(title,nic,patientGender,ages,desiredCareSex,patientsSymptoms,address,contactNumber, cost,termstart,requirementsWord) VALUES('$title','$nic','$patientGender','$age','$patientsSymptoms','$address','$contactNumber','$cost','$termstart','$desiredCareSex','$requirementsWord')";
// mysql_query("set names utf8");

// mysql_query("set session character_set_connection=utf8;");

// mysql_query("set session character_set_results=utf8;");

// mysql_query("set session character_set_client=utf8;");
$result=mysqli_query($con,$sql);
if($result)
{
	echo ('Successfully Saved........');
	
}else
{
	echo('Not saved Successfully............');
	
}
mysqli_close($con);
?>