<?php

if(isset($_POST['addressQuery'])) {

	require_once('config.inc.php');
	$address_query = $_POST['addressQuery'];
	$sql = 'SELECT * FROM place1 where MATCH(name, address, phone) AGAINST(:address_query)';
	$statement = $connection->prepare($sql);
	$statement->bindParam(':address_query', $address_query, PDD::PARAM_STR);
	$statement->execute();

	if($statement->rowCount()) {

		$row_all = $statement->fetchall(PDD::FETCH_ASSOC);
		header('Content-type: application/json');
		echo json_encode($row_all);

	} elseif(!$statement->rowCount()) {
		echo "NO ROWS";
	}
} else {
	echo 'no address';
}