<?php

$host='127.0.0.1';
$username='root';
$pwd='';
$db="taesuplace";

$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');

if(mysqli_connect_error($con))
{
	echo "Failed to Connect to Database ".mysqli_connect_error();
}

$sql = "SELECT * FROM notify";

$result=mysqli_query($con,$sql);
if($result)
{
	while($row=mysqli_fetch_array($result))
	{
		$flag[] = $row;
	}

	print(json_encode($flag));
}

mysqli_close($con);
?>