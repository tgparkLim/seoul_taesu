<?php
	header("Content_Type: text/html; charset=UTF-8");
	$host='127.0.0.1';
	$username='root';
	$pwd='';
	$db="taesuplace";

	$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');

	$userID = $_GET["userID"];

	$result = mysqli_query($con, "SELECT place1.name, place1.address ")