<?php
$host = '127.0.0.1';
$username = 'root';
$pwd = '';
$db = 'taesuplace';

//header("Content-Type: text/html; charset=UTF-8");

$con = mysqli_connect($host, $username, $pwd, $db) or die ('Unable to connect');

if(mysqli_connect_error($con)) {

	echo "Failed to connect to Database".mysqli_connect_error();

} 

$lat = $_POST['latitude'];
$lon = $_POST['longitude'];

//$sqllocation = "(SELECT latitude, longitude FROM place1) UNION ALL (SELECT address FROM place2)";

// $sqllocation = "SELECT *, 
// ( 6371 
// 	* acos( cos( radians($lat) ) * cos( radians( latitude ) ) 
// 	* cos( radians( longitude) - radians($lon) ) + sin( radians($lat) ) * sin( radians( latitude ) ) ) ) 
// AS distance FROM place1 HAVING distance < 5 ORDER BY distance LIMIT 0 , 5;";

$sqllocation = "SELECT *, 
( 6371 
	* acos( cos( radians(37) ) * cos( radians( latitude ) ) 
	* cos( radians( longitude) - radians(126) ) + sin( radians(37) ) * sin( radians( latitude ) ) ) ) 
AS distance FROM place1 HAVING distance < 5 ORDER BY distance LIMIT 0 , 5;";

mysqli_set_charset($con, 'utf8');

$result = mysqli_query($con, $sqllocation);

if($result) 
{
	while($row = mysqli_fetch_array($result)) 
	{
		$flag[] = $row;


	}

	//print(json_encode($flag, JSON_UNESCAPED_UNICODE));
	print(json_encode($flag));
	//print(json_encode($latitude, JSON_UNESCAPED_UNICODE));
	//print(json_encode($longitude, JSON_UNESCAPED_UNICODE));

} else {

	echo ('Not Found');

} mysqli_close($con);

?>