<?php
header("Content_Type: text/html; charset=UTF-8");
$host = '127.0.0.1';
$username = 'root';
$pwd = '';
$db = 'taesuplace';

//header("Content-Type: text/html; charset=UTF-8");

$con = mysqli_connect($host, $username, $pwd, $db) or die ('Unable to connect');

if(mysqli_connect_error($con)) {

	echo "Failed to connect to Database".mysqli_connect_error();

} 

mysql_query("set session character_set_connection=utf8;");

mysql_query("set session character_set_results=utf8;");

mysql_query("set session character_set_client=utf8;");

mysqli_query($con ,"set session character_set_connection=utf8;");

mysqli_query($con, "set session character_set_results=utf8;");

mysqli_query($con,"set session character_set_client=utf8;");

$sql = "SELECT * FROM find_caregiver";

$query = mysqli_query($con, $sql);

mysqli_set_charset($con, 'utf8');

if($query) {

	$return_array = array();

	while($row = mysqli_fetch_array($query, MYSQL_ASSOC)) {

		$row_array['id'] = $row['id'];
		$row_array['title'] = $row['title'];
		$row_array['nic'] = $row['nic'];
		$row_array['date'] = $row['date'];
		$row_array['patientGender'] = $row['patientGender'];
		$row_array['ages'] = $row['ages'];
		$row_array['desiredCareSex'] = $row['desiredCareSex'];
		$row_array['patientsSymptoms'] = $row['patientsSymptoms'];
		$row_array['address'] = $row['address'];
		$row_array['contactNumber'] = $row['contactNumber'];
		$row_array['cost'] = $row['cost'];
		$row_array['termstart'] = $row['termstart'];
		$row_array['requirementsWord'] = $row['requirementsWord'];

		// $row_array['id'] = $row['id'];
		// $row_array['patientGender'] = $row['patientGender'];
		// $row_array['ages'] = $row['ages'];
		// $row_array['desiredCareSex'] = $row['desiredCareSex'];
		// $row_array['patientsSymptoms'] = $row['patientsSymptoms'];
		// $row_array['address'] = $row['address'];
		// $row_array['contactNumber'] = $row['contactNumber'];
		// $row_array['requirementsWord'] = $row['requirementsWord'];


		array_push($return_array, $row_array);

	}

	echo json_encode($return_array, JSON_UNESCAPED_UNICODE);

} else {

	echo('Not Found');

} mysqli_close($con);

?>