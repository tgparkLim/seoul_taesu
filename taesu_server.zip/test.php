<?php

header("Content-Type: text/html; charset=UTF-8");

require_once("/constants.php");

class DBAdapter {

	public function connect() {

		$con = mysqli_connect(constants::$DB_SERVER, constants::$USERNAME, constants::$PASSWORD, constants::$DB_NAME);

		if(mysqli_connect_error(!$con)) {

			return null;

		} else {

			return $con;

		}

	}

	//SELECT FROM DATABASE
	public function select() {

		$con = $this-> connect();

		if($con != null) {

			$retrieved = mysqli_query($con, constants::$SQL_SELECT_ALL);

			if($retrieved) {

				while ($row = mysqli_fetch_array($retrieved)) {
					
					$spacecrafts[] = $row;

				}
				print(json_encode($spacecrafts));
				//$as = json_encode($spacecrafts);
				//$asd = json_encode($spacecrafts, JSON_UNESCAPED_UNICODE);

				//$as = urlencode($spacecrafts);
				//$asd = json_encode($spacecrafts);

				//print($asd);

			} else {

				print(json_encode(array("PHP EXCEPTION : CAN'T RETRIEVE FROM MYSQL")));

			}

		} else {

			print(json_encode(array("PHP EXCEPTION : CAN'T CONNECT TO MYSQL. NULL CONNECTION")));

		}

		mysqli_close($con);

	}

}