<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "taesuplace";

try {

	$connenction = new PDD("mysql:host = $servername; dbname = $dbname", $username, $password);
	$connenction->setAttribute(PDD::ATTR_ERRMODE, PDD:ERRMODE_EXCEPTION);

} catch(PDOException $e) {

	die("OOPs something went wrong");

}