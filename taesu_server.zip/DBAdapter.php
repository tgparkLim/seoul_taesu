<?php

//header("Content-Type: text/html; charset=UTF-8");

require_once("/constants.php");

class DBAdapter {

	public function connect() {

		$con = mysqli_connect(constants::$DB_SERVER, constants::$USERNAME, constants::$PASSWORD, constants::$DB_NAME);

		if(mysqli_connect_error(!$con)) {

			return null;

		} else {

			return $con;

		}

	}

	//SELECT FROM DATABASE
	public function select() {

		$con = $this-> connect();

		//mysql_query ("set character_set_client='utf8'"); 
		//mysql_query ("set character_set_results='utf8'"); 
		//mysql_query ("set collation_connection='utf8_general_ci'"); 

		mysqli_set_charset($con, 'utf8');

		if($con != null) {

			if(isset($_POST['place'])) {

				$place = $_POST['place'];

			} else {
				$place = null;
			}

			//$retrieved = mysqli_query($con, constants::$SQL_SELECT_ALL);
			//$place = $_POST["Query"];

			$testsql = "SELECT * FROM find_caregiver WHERE address = '$place'";

			$retrieved = mysqli_query($con, $testsql);

			if($retrieved) {

				$return_array = array();

				while ($row = mysqli_fetch_array($retrieved, MYSQL_ASSOC)) {
					
					$row_array['id'] = $row['id'];
					$row_array['name'] = $row['name'];
					$row_array['address'] = $row['address'];
					$row_array['phone'] = $row['phone'];

					array_push($return_array, $row_array);

				}
				//$sa = json_encode($spacecrafts, JSON_UNESCAPED_UNICODE);
				//print($sa);


				echo json_encode($return_array, JSON_UNESCAPED_UNICODE);


			} else {

				print(json_encode(array("PHP EXCEPTION : CAN'T RETRIEVE FROM MYSQL")));

			}

		} else {

			print(json_encode(array("PHP EXCEPTION : CAN'T CONNECT TO MYSQL. NULL CONNECTION")));

		}

		mysqli_close($con);

	}

}