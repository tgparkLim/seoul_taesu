<?php

require_once("/DBAdapter.php");

	$dbAdapter = new DBAdapter();
	$dbAdapter -> select();