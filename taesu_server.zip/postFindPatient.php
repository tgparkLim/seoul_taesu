<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php

header("Content-Type:text/html; charset=utf-8");

$host='127.0.0.1';
$username='root';
$pwd='';
$db="taesuplace";
$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');
mysql_query("set names utf8");

mysql_query("set session character_set_connection=utf8;");

mysql_query("set session character_set_results=utf8;");

mysql_query("set session character_set_client=utf8;");

if(mysqli_connect_error($con))
{
	echo "Failed to Connect to Database ".mysqli_connect_error();
}
$title=$_POST['title'];
$nic=$_POST['nic'];
// $date=$_POST['desiredCareSex'];
$gender=$_POST['gender'];
$age=$_POST['age'];
$phone=$_POST['phone'];
$certify=$_POST['certify'];
$job=$_POST['job'];
$address=$_POST['address'];
$cost=$_POST['cost'];
$term=$_POST['term'];
$hopegender=$_POST['hopegender'];
$content=$_POST['content'];

//'
$sql="INSERT INTO find_patient
(title,nic,gender,age,phone,certify,job,hopelocation,hopecost,startdate,hopegender,content)
					 VALUES('$title','$nic','$gender','$age','$phone','$certify','$job'
					 ,'$address','$cost','$term','$hopegender','$content')";
// mysql_query("set names utf8");

// mysql_query("set session character_set_connection=utf8;");

// mysql_query("set session character_set_results=utf8;");

// mysql_query("set session character_set_client=utf8;");
$result=mysqli_query($con,$sql);
if($result)
{
	echo ('Successfully Saved........');
	
}else
{
	echo('Not saved Successfully............');
	
}
mysqli_close($con);
?>