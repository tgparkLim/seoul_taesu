<?php
$host = '127.0.0.1';
$username = 'root';
$pwd = '';
$db = 'taesuplace';

//header("Content-Type: text/html; charset=UTF-8");

$con = mysqli_connect($host, $username, $pwd, $db) or die ('Unable to connect');

if(mysqli_connect_error($con)) {

	echo "Failed to connect to Database".mysqli_connect_error();

} 

mysql_query("set session character_set_connection=utf8;");

mysql_query("set session character_set_results=utf8;");

mysql_query("set session character_set_client=utf8;");

mysqli_query($con ,"set session character_set_connection=utf8;");

mysqli_query($con, "set session character_set_results=utf8;");

mysqli_query($con,"set session character_set_client=utf8;");


$place = $_POST['Query'];

$sql = "SELECT * FROM place2 WHERE address LIKE '%$place%'";

$query = mysqli_query($con, $sql);

mysqli_set_charset($con, 'utf8');
if($query) {

	$return_array = array();

	while($row = mysqli_fetch_array($query, MYSQL_ASSOC)) {

		$row_array['id'] = $row['id'];
		$row_array['name'] = $row['name'];
		$row_array['category'] = $row['category'];
		$row_array['address'] = $row['address'];
		$row_array['phone'] = $row['phone'];
		//$row_array['cost'] = $row['cost'];
		//$row_array['age'] = $row['age'];
		//$row_array['gender'] = $row['gender'];

		$row_array['link'] = $row['link'];
		$row_array['size'] = $row['size'];
		$row_array['people'] = $row['people'];


		array_push($return_array, $row_array);

	}

	echo json_encode($return_array, JSON_UNESCAPED_UNICODE);

} else {

	echo('Not Found');

} mysqli_close($con);

?>
