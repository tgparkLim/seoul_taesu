<?php

$host='127.0.0.1';
$username='root';
$pwd='';
$db="taesuplace";

$con=mysqli_connect($host,$username,$pwd,$db);

$userID = $_POST["userID"];
$place1ID = $_POST['place1ID'];

$statement = mysqli_prepare($con, "INSERT INTO place1bookmark VALUES(?, ?)");
mysqli_stmt_bind_param($statement, )