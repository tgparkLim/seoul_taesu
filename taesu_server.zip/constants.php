<?php

class Constants {
	
	//DATABASE DETAILS
	static $DB_SERVER = "localhost";
	static $DB_NAME = "taesuplace";
	static $USERNAME = "root";
	static $PASSWORD = "";
	const TB_NAME = "find_caregiver";

	//STATEMENTS
	static $SQL_SELECT_ALL = "SELECT * FROM find_caregiver";
	static $SQL_SELECT_WHERE_KANGNAM = "SELECT * FROM find_caregiver WHERE address";

}