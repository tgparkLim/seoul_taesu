<?php
	$host='127.0.0.1';
	$username='root';
	$pwd='';
	$db="taesuplace";

	$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');

	$userID = $_POST["userID"];
	$userPassword = $_POST["userPassword"];
	$userNic = $_POST["userNic"];
	$userGender = $_POST["userGender"];
	$userAge = $_POST["userAge"];
	$userAddress = $_POST["userAddress"];

	$statement = mysqli_prepare($con, " INSERT INTO USER VALUES (?,?,?,?,?,?)");
	mysqli_stmt_bind_param($statement, "ssssss", $userID, $userPassword, $userNic, $userGender, $userAge, $userAddress);
	mysqli_stmt_execute($statement);

	$response = array();
	$response["success"] = true;

	echo json_encode($response);
	?>